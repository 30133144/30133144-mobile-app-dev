# Music Library API Project Report

## Theme Choice Justification
The Music Library Management theme was chosen for this API project because:
1. It provides a clear hierarchical data structure (Artists -> Albums -> Tracks)
2. It demonstrates many-to-many relationships common in real-world applications
3. It allows for comprehensive CRUD operations with meaningful relationships
4. It's easily extensible and scalable for future features

## Database Structure
The database uses MongoDB with three main collections:
- Artists (name, genre, country, etc.)
- Albums (title, artist reference, release year, etc.)
- Tracks (title, album reference, duration, etc.)

## API Endpoints Overview

### Authentication Endpoints 

POST /api/auth/register
Register new user with username, email, and password
Returns JWT token
POST /api/auth/login
Login with email and password
Returns JWT token

### Artist Endpoints

GET /api/artists
Retrieve all artists
Requires authentication

GET /api/artists/:id
Retrieve specific artist
Requires authentication

POST /api/artists
Create new artist
Requires authentication
Accepts: name, genre, country, formedYear

PATCH /api/artists/:id
Update artist details
Requires authentication

DELETE /api/artists/:id
Delete artist
Requires authentication

### Album Endpoints

GET /api/albums
Retrieve all albums
Requires authentication

POST /api/albums
Create new album
Requires authentication
Accepts: title, artistId, releaseYear, genre

PATCH /api/albums/:id
Update album details
Requires authentication

DELETE /api/albums/:id
Delete album
Requires authentication

### Track Endpoints

GET /api/tracks
Retrieve all tracks
Includes album and artist details
Requires authentication

POST /api/tracks
Create new track
Requires authentication
Accepts: title, artistId, albumId, duration, trackNumber, genre



## Testing Overview
The API includes comprehensive unit tests using Jest and Supertest:

1. Authentication Tests
- User registration
- User login
- Token validation

2. Artist Tests
- Create artist
- Retrieve artists
- Update artist
- Delete artist

3. Album Tests
- Album creation with artist reference
- Album retrieval with populated artist data
- Album updates and deletion

4. Track Tests
- Track creation with album and artist references
- Track retrieval with populated data
- Track management within albums

## Code Repository
[Link to GitHub Repository]

## Technologies Used
- Node.js and Express.js for API development
- MongoDB for database
- JWT for authentication
- Jest and Supertest for testing
- Mongoose for database modeling

## Security Features
- Password hashing using bcrypt
- JWT-based authentication
- Protected routes requiring valid tokens
- Input validation and sanitization