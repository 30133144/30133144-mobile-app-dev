const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Track = require('../models/Track');
const Album = require('../models/Album');

// Get all tracks
router.get('/', auth, async (req, res) => {
    try {
        const tracks = await Track.find()
            .populate('album')
            .populate('artist');
        res.json(tracks);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get single track
router.get('/:id', auth, async (req, res) => {
    try {
        const track = await Track.findById(req.params.id)
            .populate('album')
            .populate('artist');
        if (!track) return res.status(404).json({ error: 'Track not found' });
        res.json(track);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Create track
router.post('/', auth, async (req, res) => {
    try {
        const track = new Track(req.body);
        await track.save();
        
        // Update album's tracks array
        if (track.album) {
            await Album.findByIdAndUpdate(
                track.album,
                { $push: { tracks: track._id } }
            );
        }
        
        res.status(201).json(track);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Update track
router.patch('/:id', auth, async (req, res) => {
    try {
        const track = await Track.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        );
        if (!track) return res.status(404).json({ error: 'Track not found' });
        res.json(track);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Delete track
router.delete('/:id', auth, async (req, res) => {
    try {
        const track = await Track.findByIdAndDelete(req.params.id);
        if (!track) return res.status(404).json({ error: 'Track not found' });
        
        // Remove track from album's tracks array
        if (track.album) {
            await Album.findByIdAndUpdate(
                track.album,
                { $pull: { tracks: track._id } }
            );
        }
        
        res.json({ message: 'Track deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router; 