const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Artist = require('../models/Artist');

// Get all artists
router.get('/', auth, async (req, res) => {
    try {
        const artists = await Artist.find();
        res.json(artists);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get single artist
router.get('/:id', auth, async (req, res) => {
    try {
        const artist = await Artist.findById(req.params.id);
        if (!artist) return res.status(404).json({ error: 'Artist not found' });
        res.json(artist);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Create artist
router.post('/', auth, async (req, res) => {
    try {
        const artist = new Artist(req.body);
        await artist.save();
        res.status(201).json(artist);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Update artist
router.patch('/:id', auth, async (req, res) => {
    try {
        const artist = await Artist.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        );
        if (!artist) return res.status(404).json({ error: 'Artist not found' });
        res.json(artist);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Delete artist
router.delete('/:id', auth, async (req, res) => {
    try {
        const artist = await Artist.findByIdAndDelete(req.params.id);
        if (!artist) return res.status(404).json({ error: 'Artist not found' });
        res.json({ message: 'Artist deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router; 