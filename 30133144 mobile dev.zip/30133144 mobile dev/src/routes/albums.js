const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Album = require('../models/Album');

// Get all albums
router.get('/', auth, async (req, res) => {
    try {
        const albums = await Album.find().populate('artist');
        res.json(albums);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get single album
router.get('/:id', auth, async (req, res) => {
    try {
        const album = await Album.findById(req.params.id).populate('artist');
        if (!album) return res.status(404).json({ error: 'Album not found' });
        res.json(album);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Create album
router.post('/', auth, async (req, res) => {
    try {
        const album = new Album(req.body);
        await album.save();
        res.status(201).json(album);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Update album
router.patch('/:id', auth, async (req, res) => {
    try {
        const album = await Album.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        );
        if (!album) return res.status(404).json({ error: 'Album not found' });
        res.json(album);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Delete album
router.delete('/:id', auth, async (req, res) => {
    try {
        const album = await Album.findByIdAndDelete(req.params.id);
        if (!album) return res.status(404).json({ error: 'Album not found' });
        res.json({ message: 'Album deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router; 