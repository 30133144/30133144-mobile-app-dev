const request = require('supertest');
const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
let app;

let mongoServer;
let token;

jest.setTimeout(30000); // Increase timeout to 30 seconds

beforeAll(async () => {
    try {
        // Create an in-memory MongoDB instance
        mongoServer = await MongoMemoryServer.create();
        const mongoUri = mongoServer.getUri();

        // Disconnect from any existing connection
        if (mongoose.connection.readyState !== 0) {
            await mongoose.disconnect();
        }

        // Connect to the in-memory database
        await mongoose.connect(mongoUri, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });

        // Import app after database connection is established
        app = require('../index');

        // Create test user and generate token
        const user = await User.create({
            username: 'testuser',
            email: 'test@test.com',
            password: 'password123'
        });
        
        token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET);
    } catch (error) {
        console.error('BeforeAll Error:', error);
        throw error;
    }
}, 30000);

afterAll(async () => {
    try {
        if (mongoose.connection.readyState !== 0) {
            await mongoose.disconnect();
        }
        if (mongoServer) {
            await mongoServer.stop();
        }
        if (app && app.close) {
            await new Promise((resolve) => app.close(resolve));
        }
    } catch (error) {
        console.error('AfterAll Error:', error);
    }
}, 30000);

beforeEach(async () => {
    if (mongoose.connection.readyState !== 0) {
        await mongoose.connection.dropDatabase();
    }
});

describe('Artist API', () => {
    test('should create a new artist', async () => {
        const response = await request(app)
            .post('/api/artists')
            .set('Authorization', `Bearer ${token}`)
            .send({
                name: 'Test Artist',
                genre: ['Rock'],
                country: 'USA'
            });
        
        expect(response.status).toBe(201);
        expect(response.body.name).toBe('Test Artist');
    }, 10000);

    test('should get all artists', async () => {
        const response = await request(app)
            .get('/api/artists')
            .set('Authorization', `Bearer ${token}`);
        
        expect(response.status).toBe(200);
        expect(Array.isArray(response.body)).toBeTruthy();
    }, 10000);
}); 